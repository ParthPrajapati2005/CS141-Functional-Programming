
import Hatch
import Ants

-- This imports the runAnimation IO operation defined in "Hatch", and the "animation" value defined in "Ants", and uses that to run the animation.

main :: IO ()
main = runAnimation animation