module Hurtle.GUI where
import Hurtle.Parser
import Hurtle.Turtle
import Hurtle.Types
import Graphics.Gloss
import Graphics.Gloss.Juicy
import Graphics.Gloss.Interface.IO.Game
import Graphics.UI.TinyFileDialogs
import Data.Text
import System.IO
import Text.Megaparsec
import Control.Monad.State
import System.IO.Unsafe (unsafePerformIO)
import GHC.Word

-------------------------------------------------------------- HELPER FUNCTIONS ---------------------------------------------------------

-- Check if the mouse click is inside the button
isInsideButton :: (Float, Float) -> (Float, Float) -> Float -> Float -> Bool
isInsideButton (x, y) (buttonX, buttonY) buttonWidth buttonHeight =
  x >= buttonX - buttonWidth / 2 &&
  x <= buttonX + buttonWidth / 2 &&
  y >= buttonY - buttonHeight / 2 &&
  y <= buttonY + buttonHeight / 2

--Create rectangle with text
rectangleWithText :: String -> Float -> Float -> Picture
rectangleWithText textInput width height =
    let buttonText = scale 0.3 0.3 $ color black $ text textInput
    in pictures [rectangleWire width height, translate (-70) (-15) buttonText]

-------------------------------------------------------------- START SCREEN --------------------------------------------------------------

-- Initial state
initialState :: HurtleState
initialState = Started

-- Render function
-- Render function
render :: Picture -> HurtleState -> Picture
render bg hurtleState = case hurtleState of
    Started -> pictures [translate 0 50 bg, translate 0 (-220) (rectangleWithText "Start !!" 400 80)]
    OpenFile x -> createTurtleGUI (getTurtleState x)

-- Handle events
handleHurtle :: Event -> HurtleState -> IO HurtleState
handleHurtle (EventKey (MouseButton LeftButton) Down _ (x, y)) hurtleState = case hurtleState of
    Started
        | isInsideButton (x, y) (0,-220) 400 80 -> do
            filePath <- openFileDialogPopup
            color <- Hurtle.GUI.colorChooser (0, 0, 0)
            hogoProgram <- parsingProcess filePath
            pure (OpenFile hogoProgram)
        | otherwise -> pure hurtleState

    _ -> pure hurtleState
handleHurtle _ hurtleState = pure hurtleState

-- Update function
update :: Float -> HurtleState -> IO HurtleState
update _ = pure

-------------------------------------------------------------- FILE OPEN --------------------------------------------------------------

openFileDialogPopup :: IO String
openFileDialogPopup = do
    x <- Graphics.UI.TinyFileDialogs.openFileDialog (pack "Select Hogo File to Parse") (pack "") [pack "*.hogo"] (pack "*.hogo") False  --Check of *hogo may not work on linux. But works on windows
    filePath  <- case x of
            Just a -> pure a
            Nothing -> error "Error while recieving input file!"
    print filePath
    pure (getStringFilePath filePath)

getStringFilePath :: [Text] -> String
getStringFilePath [] = ""
getStringFilePath (x:_) = unpack x

------------------------------------------------------------- PARSE HOGO FILE ----------------------------------------------------------

parsingProcess :: String -> IO HogoProgram
parsingProcess filePath = do
    fileHandler <- openFile filePath ReadMode
    fileContent <- hGetContents fileHandler

    case parseMaybe parseHogo fileContent of
        Just y -> pure y
        Nothing  -> error "Error parsing the given input! Please give a valid Hogo file."


------------------------------------------------------------- GET TURTLE STATE ---------------------------------------------------------

getTurtleState :: HogoProgram -> TurtleState
getTurtleState hogoProgram = execState (runTurtle hogoProgram) initialTurtleState

---------------------------------------------------------------- COLOR CHOOSER ---------------------------------------------------------

colorChooser :: (GHC.Word.Word8, GHC.Word.Word8, GHC.Word.Word8) -> IO (GHC.Word.Word8, GHC.Word.Word8, GHC.Word.Word8)
colorChooser (r, g, b) = do
    x <- Graphics.UI.TinyFileDialogs.colorChooser (pack "Choose a Line Colour") (r, g, b)
    case x of
        Just a -> pure a
        Nothing -> error "Error while recieving color!"

------------------------------------------------------------------ DRAW ----------------------------------------------------------------

turtleImage :: IO Picture
turtleImage = do
    maybePic <- loadJuicyPNG "./assets/turtle.png"
    let out = case maybePic of
            Just pic -> pic
            Nothing -> error "Error while loading the image!"
    pure $ scale 0.06 0.06 out

convertToLines :: [((Float, Float), (Float, Float))] -> [Picture]
convertToLines = Prelude.map (\((x1, y1), (x2, y2)) -> Line [(x1, y1), (x2, y2)])

getLastCoordinate :: [((Float, Float), (Float, Float))] -> (Float, Float)
getLastCoordinate [] = (0, 0)
getLastCoordinate x = snd (Prelude.last x)

createTurtleGUI :: TurtleState -> Picture
createTurtleGUI turtleState =
    pictures $ convertToLines (linesDrawnSoFar turtleState) ++ [uncurry translate (position turtleState) (rotate (angle turtleState) $ unsafePerformIO turtleImage)]