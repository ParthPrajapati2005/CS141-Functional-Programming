module Hurtle.Turtle where
import Hurtle.Types
import Control.Monad.State

-- | This is the initial state of the turtle.
initialTurtleState :: TurtleState
initialTurtleState = TurtleState {
    position = (0, 0),
    angle = 0,
    penDown = True,
    linesDrawnSoFar = []
}

-- | This function moves the turtle forward by a given distance.
goForwardM :: Float -> TurtleMonad ()
goForwardM distance = do
    currentState <- get
    let (x, y) = position currentState
        angle' = angle currentState
        newX = x + distance * sin (angle' * pi / 180 )
        newY = y + distance * cos (angle' * pi / 180 )
    if penDown currentState
        then modify (\s -> s { position = (newX, newY), linesDrawnSoFar = linesDrawnSoFar s ++ [(position currentState, (newX, newY))] })
        else modify (\s -> s { position = (newX, newY) })

-- | This function moves the turtle backward by a given distance.
goBackwardM :: Float -> TurtleMonad ()
goBackwardM distance = goForwardM (-distance)

-- | This function turns the turtle left by a given angle.
turnLeftM :: Float -> TurtleMonad ()
turnLeftM angle' = modify (\s -> s { angle = angle s - angle' })

-- | This function turns the turtle right by a given angle.
turnRightM :: Float -> TurtleMonad ()
turnRightM angle' = turnLeftM (-angle')

-- | This function puts the pen down.
penDownM :: TurtleMonad ()
penDownM = modify (\s -> s { penDown = True })

-- | This function puts the pen up.
penUpM :: TurtleMonad ()
penUpM = modify (\s -> s { penDown = False })

runTurtle :: HogoProgram -> TurtleMonad ()
runTurtle [] = pure ()
runTurtle (x:xs) = case x of
    GoForward y -> goForwardM y >> runTurtle xs
    GoBackward y -> goBackwardM y >> runTurtle xs
    TurnLeft y -> turnLeftM y >> runTurtle xs
    TurnRight y -> turnRightM y >> runTurtle xs
    PenUp -> penUpM >> runTurtle xs
    PenDown -> penDownM >> runTurtle xs
    ClearScreen -> modify (\s -> s {position = (0,0), angle = 0, linesDrawnSoFar = [] }) >> runTurtle xs
    GoHome -> modify (\s -> s { position = (0, 0), angle = 0 }) >> runTurtle xs
    Repeat n y -> replicateM_ n (runTurtle y) >> runTurtle xs