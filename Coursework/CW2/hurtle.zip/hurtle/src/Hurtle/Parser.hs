module Hurtle.Parser (parseHogo) where
import Hurtle.Types

-- You'll probably want to refer to https://hackage.haskell.org/package/megaparsec for documentation of the Megaparsec library.
import Text.Megaparsec
import Text.Megaparsec.Char
import Text.Megaparsec.Char.Lexer

{-
   This is the main parser which will continually parse the contents of the input given until the end of the file is reached. It may also be the case that the 
   parser encounters an error before the end of the file. In this case, it will throw the respective error. The <* is an applicative operator which applies 
   both parsers in turn, and discards the result of the second parser. Here, it will execute the parseInstrcutions parser as far as it can go. If it does not 
   result in an error, it will try to parse the end of file. In other words, I am ensuring that after parseInstructions has completed, it must be followed by 
   the end of the file. Else, there is a problem and a parse error will be thrown. This is an error while parsing a HogoProgram as for it to be valid,
   the entire program should successfully parse before the end of input.  
-}
parseHogo :: Parser HogoProgram
parseHogo = parseInstructions <* eof

{-
    This is the parser which will run each of the sub-parsers which are part of the "parserList". I use the <$> fmap operator with the concat function to 
    concatenate the output of running all of the parsers. The "choice" operator will essentially use the <|> on each of the parsers contained within the 
    "parserList" list. This is the usage of the "alternative" operator which will combine the values with the first successful parser. I could have also 
    written this in one line like this : parseMovement <|> parseClearscreen <|> ... however, I did not do this as this is not elegant code. I instead 
    split this into a list of functions. This is much more readable, and elegant code. The "many" parser then runs each parser within the list an
    unbounded number of times until it can no longer parse. It then returns its result as a list, and the "concat" function then combines all of these
    values into one list. For example the output of many could be : [[GoForward 10.0], [GoBackward 5.1], []], which is then converted into 
    [GoForward 10.0, GoBackward 5.1]. It will "fmap" over each of the sub-lists, run the concat function and return the output. As shown in the labs, 
    I could have also have used a recurive technique by calling parseInstrcuctions at the end of every parser in the list. However, I do not do this
    and use the "concat" function to do this iteratively. This is much more efficient and space efficient code, as the recursive technique would
    result in the whole call stack being stored in memory, which could be bad given a large input.
-}
parseInstructions :: Parser HogoProgram
parseInstructions = concat <$> many (choice parserList)

{-
    This is the parserList descibed in the justification of "parseInstructions". It is a list of all of the HogoProgram parsers which are utilised to 
    parse a given input. This is an example of having modular and elegant code, as if another parser needs to be added, this is the only place that 
    change needs to be made. The change is then reflected throughout the program. 
-}
parserList :: [Parser HogoProgram]
parserList =
    [
        -- parseForward,        --These are the alternative parsers which can be used to parse the movement commands instead of the parseMovement. 
        -- parseBack,
        -- parseLeft,
        -- parseRight,
        parseMovement,
        -- parseHome,           --These are the alternative parsers which can be used to parse the utility commands instead of the parseUtility.
        -- parsePenup,
        -- parsePendown,
        -- parseClearscreen,
        parseRepeat,
        parseUtility,
        parseComment,
        parseWhiteSpace
    ]

{-
    This is the parser which handles the parsing of comments. It will parse the string ";" and then take all characters until it reaches a newline character.
    The "takeWhileP" parser will take all characters until a given predicate is satisfied. In this case, the predicate is that the character is not a newline.
    It then returns an empty list as comments are not part of the program. I do this using do notation. 
-}
parseComment :: Parser HogoProgram
parseComment = do
    _ <- char ';'
    _ <- takeWhileP (Just "non-newline characters") (/= '\n')
    pure []

{-
    This is the parser which will parse whitespace. It will parse any number of spaces or newline characters. It will then return an empty list as whitespace
    is not part of the program. It also parses the sitation where the end of the line is reached. This is done using the "eol" parser which will parse the 
    end of the line. I could have also removed the use of the "some" parser. However, this is inefficient as if the input has multiple consecutie spaces, then 
    the parser will return [] that many times. For example if the input is "     ", then the parser will return [] 5 times. This is not efficient, and so 
    I use the "some" parser which will parse all of the spaces in one go and return them as a single list. This is much more space efficient. The "some" parser
    also ensures that the parser runs at least once, as if "many" is used, then the parser may get stuck in an infinite loop. This is because the "many" parser
    consumes the input 0 or more times. If the input is empty, then the parser will run infinitely. This is not the case with the "some" parser. 
-}
parseWhiteSpace :: Parser HogoProgram
parseWhiteSpace = do
    _ <- some (string " " <|> string "\n" <|> eol)
    pure []

{-
    This is the parser which will parse a floating point number. It will use the "try" parser to ensure that the parser does not consume any input if it fails
    to parse a floating point number. If it does fail, it then attemps to parse the same input as a decimal (which includes integers). If this also fails, then
    the parser will throw an error. The parser will however, always return a floating point number - even if it is given an integer input. This is used when 
    the movement commands are parsed. For example "forward 10" will be parsed as "GoForward 10.0". 
-}
parseNumber :: Parser Float
parseNumber = try float <|> decimal

{-
    This is the parse which will parse all of the movement commands. The parser will parse the string "forward" or "back" or "left" or "right", followed by a
    space character, followed by a floating point number. It will then return the respective movement command. This is done by pattern matching by using a 
    case..of statement. I had initially written this parser as 4 separate parsers, however, I then realised that this is not efficient. This is because there
    is a lot of repeated code. I then refactored this into a single parser. This is much more efficient, and elegant code. The previous implementation
    can be seen at the bottom of this file. It can also be updated with further keywords, which follow the same structure of "<keyword> <floating point number>".
    I believe that the current implementation is clean, readable and efficient.
-}
parseMovement :: Parser HogoProgram
parseMovement = do
    x <- string "forward" <|>  string "back" <|>  string "left" <|> string "right"
    _ <- Text.Megaparsec.Char.space
    y <- parseNumber
    case x of
        "forward" -> pure [GoForward y]
        "back" -> pure [GoBackward y]
        "left" -> pure [TurnLeft y]
        "right" -> pure [TurnRight y]
        _ -> error "Movement command must be forward, back, left or right!"  --This should never be reached as the parser will only parse the strings "forward", "back", "left" or "right", however it is included for completeness.

{-
    This is the parser which will parse all of the utility commands. The parser will parse the string "home" or "penup" or "pendown" or "clearscreen". It will
    then return the respective utility command. This is done by pattern matching by using a case..of statement. Similar to the parseMovement parser, I had 
    originally written this as 4 separate parsers, however, I then realised that this is not efficient. Thus, I refactored this into a single parser. The old
    implementation can be seen at the bottom of this file. The parser can also be updated with further keywords, which follow the same structure of "<keyword>".
-}
parseUtility :: Parser HogoProgram
parseUtility = do
    x <- string "home" <|> string "penup" <|> string "pendown" <|> string "clearscreen"
    case x of
        "home" -> pure [GoHome]
        "penup" -> pure [PenUp]
        "pendown" -> pure [PenDown]
        "clearscreen" -> pure [ClearScreen]
        _ -> error "Utility command not valid"  --This should never be reached as the parser will only parse the strings "home", "penup", "pendown" or "clearscreen", however it is included for completeness.

{-
    This is the parser which will parse the repeat command. It will parse and repeat a given "codeBlock" a given number of times. This "codeBlock" is extracted
    using the "between" which parses the content which is between the 2 given characters '[' `and`]'. The parser then uses explicit recursion to parse the 
    "codeBlock" inside. This is done by using the "parseInstructions" parser. This also means that it is possible to have nested repeat commands. When the
    parser has successfully parsed the "codeBlock", it then returns a Repeat HogoCode. This is the only place in the program where explicit recursion is used. 
-}
parseRepeat :: Parser HogoProgram
parseRepeat = do
    _ <- string "repeat"                                            --Parse the string "repeat"
    _ <- Text.Megaparsec.Char.space                                 --Parse a space character
    x <- decimal                                                    --Parse a decimal number
    _ <- Text.Megaparsec.Char.space                                 --Parse a space character 
    codeBlock <- between (char '[') (char ']') parseInstructions    --Recursively parse the codeBlock by calling parseInstructions
    pure [Repeat x codeBlock]                                       --Return the Repeat instruction                    

-------------------------------------------------------------------------------------------------------

--parseMovement alternative:
{-
parseForward :: Parser HogoProgram
parseForward = do
    _ <- string "forward"            --Parse the string "forward"
    _ <- Text.Megaparsec.Char.space  --Parse a space character
    x <- parseNumber                 --Parse a floating point number
    pure [GoForward x]               --Parse a floating point number and return it as a GoForward instruction
 
parseBack :: Parser HogoProgram
parseBack = do
    _ <- string "back"               --Parse the string "backward"
    _ <- Text.Megaparsec.Char.space  --Parse a space character
    x <- parseNumber                 --Parse a floating point number
    pure [GoBackward x]              --Parse a floating point number and return it as a GoBackward instruction

parseLeft :: Parser HogoProgram
parseLeft = do
    _ <- string "left"               --Parse the string "left"
    _ <- Text.Megaparsec.Char.space  --Parse a space character
    x <- parseNumber                 --Parse a floating point number
    pure [TurnLeft x]                --Parse a floating point number and return it as a TurnLeft instruction

parseRight :: Parser HogoProgram
parseRight = do
    _ <- string "right"              --Parse the string "right"
    _ <- Text.Megaparsec.Char.space  --Parse a space character
    x <- parseNumber                 --Parse a floating point number
    pure [TurnRight x]               --Parse a floating point number and return it as a TurnRight instruction

-}

--parseUtility alternative:
{-
parseClearscreen :: Parser HogoProgram
parseClearscreen = do
    _ <- string "clearscreen"        --Parse the string "clearscreen"
    pure [ClearScreen]               --Return a ClearScreen instruction

parseHome :: Parser HogoProgram
parseHome = do
    _ <- string "home"               --Parse the string "home"
    pure [GoHome]                    --Return a GoHome instruction

parsePenup :: Parser HogoProgram
parsePenup = do
    _ <- string "penup"              --Parse the string "penup"
    pure [PenUp]                     --Return a PenUp instruction

parsePendown :: Parser HogoProgram
parsePendown = do
    _ <- string "pendown"            --Parse the string "pendown"
    pure [PenDown]                   --Return a PenDown instruction
-}
