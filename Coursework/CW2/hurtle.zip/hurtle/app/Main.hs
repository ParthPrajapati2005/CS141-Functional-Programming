-- This is the main entry point for your Hurtle viewer.s

import Hurtle.GUI
import Graphics.Gloss
import Graphics.Gloss.Juicy
import Graphics.Gloss.Interface.IO.Game

-- Function to display the window with the image
main :: IO ()
main = do
  picture <- loadJuicyPNG "./assets/splashscreen.png"
  let bg = case picture of
                Just pic -> pic
                Nothing -> error "Error while loading the image!"

  playIO (InWindow "Hurtle - The Haskell Logo Turtle" (1500, 800) (10, 10)) white 30 initialState (pure . render bg) handleHurtle update

-- main :: IO ()
-- main = do
--     --notifyPopup (pack "hi") (pack "sometext") Error
--     --openFileDialog (pack "hi") (pack []) (pack "yo") False
--     --color <- colorChooser (pack "Choose a color") (0,0,0)

--     ---------------------------------------------------
--     x <- openFileDialog (pack "Select Hogo File to Parse") (pack "") [(pack "*.hogo")] (pack "*.hogo") False  --Check of *hogo may not work on linux. But works on windows
--     filePath  <- case x of
--             Just a -> pure a
--             Nothing -> error "Error while recieving input file!"
    
--     fileHandler <- openFile (getStringFilePath filePath) ReadMode
--     fileContent <- hGetContents fileHandler

--     parseResult <- case (parseMaybe parseHogo fileContent) of
--         Just y -> pure y
--         Nothing  -> error "Error parsing the given input!"
    
--     color <- colorChooser (pack "Choose a color") (0,0,0)
    
--     print parseResult

--     return () 

-- getStringFilePath :: [Text] -> String
-- getStringFilePath [] = ""
-- getStringFilePath (x:_) = unpack x

