# CS141 Coursework 1 2022-23: Bean's Gambit
## A Strategy Game for Two Players
